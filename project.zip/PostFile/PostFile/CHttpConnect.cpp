
#include "CHttpConnect.h"
#include <WinSock.h>
#include <stdio.h>
#include <sstream>
#include <iostream>
#include <algorithm>
#ifdef WIN32
#pragma comment(lib,"ws2_32.lib")
#endif
CHttpConnect::CHttpConnect()
{
}
CHttpConnect::~CHttpConnect(void)
{
}
short CHttpConnect::ParseUrl(std::string& host, std::string& path)
{
    short nPort = 80;
    //���������������ܴ�http��ͷ
    int pos = host.find("http://");
    if (pos >= 0)
    {
        int endPos = host.find("/", pos + 7);
        if (endPos >= 0)
        {
            path = host.substr(endPos, host.length() - endPos);
            host = host.substr(pos + 7, endPos - pos - 7);
        }
        else
        {
            host = host.substr(pos + 7, host.length() - pos - 7);
        }
        pos = host.find(":");
        if (pos >= 0)
        {
            string sPort = host.substr(pos + 1, host.length() - pos - 1);
            nPort = atoi(sPort.c_str());
            host = host.substr(0, pos);
        }
    }
    else
    {
        int endPos = host.find("/");
        if (endPos >= 0)
        {
            path = host.substr(endPos, host.length() - endPos);
            host = host.substr(0, endPos);
        }
        pos = host.find(":");
        if (pos >= 0)
        {
            string sPort = host.substr(pos + 1, host.length() - pos - 1);
            nPort = atoi(sPort.c_str());
            host = host.substr(0, pos);
        }
    }
    return nPort;
}
std::string CHttpConnect::SocketHttp(std::string host, std::string request, short port, pfn_write_data pwrite_data, void* pattach)
{
#ifdef WIN32
    //�˴�һ��Ҫ��ʼ��һ�£�����gethostbyname����һֱΪ��
    WSADATA wsa = { 0 };
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
    int sockfd;
    struct sockaddr_in address;
    struct hostent *server;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    server = gethostbyname(host.c_str());
    memcpy((char *)&address.sin_addr.s_addr, (char*)server->h_addr, server->h_length);
    if (-1 == connect(sockfd, (struct sockaddr *)&address, sizeof(address))) {
        //ASSERT("����ʧ��");
        return "";
    }
#ifdef WIN32
    send(sockfd, request.c_str(), request.size(), 0);
#else
    write(sockfd, request.c_str(), request.size());
#endif
    char buf[1024];
    int actual = -1;
    bool checkHttpHead = true;
    LPCSTR lpLine = NULL;
    std::stringstream out;
#ifdef WIN32
    while (actual = recv(sockfd, buf, 1024, 0))
#else
    while (actual = read(sockfd, buf, 1024))
#endif
    {
        if (checkHttpHead)
        {
            if ((lpLine = strstr(buf, "\r\n\r\n")))
            {
                int offset = lpLine - buf + strlen("\r\n\r\n");//���ֵ�ָ���ȥ��ʼָ��õ�����
                if (pwrite_data == NULL)
                    out << string(buf + offset, actual - offset) << endl;//����д������
                else
                    pwrite_data(buf + offset, 1, actual - offset, pattach);
                checkHttpHead = false;//httpͷ��ȡ���
                lpLine = NULL;//ָ��ſ�
            }
            continue;
        }
        if (pwrite_data == NULL)
            out << string(buf, actual) << endl;//����д������
        else
            pwrite_data(buf, 1, actual, pattach);
    }
#ifdef WIN32
    closesocket(sockfd);
    //�˴�һ��Ҫ��ʼ��һ�£�����gethostbyname����һֱΪ��
    ::WSACleanup();
#else
    close(sockfd);
#endif
    string str_result = out.str();
    return str_result;
}
std::string CHttpConnect::HttpPost(std::string host, std::string post)
{
    string path;
    short nPort = ParseUrl(host, path);
    //POST����ʽ
    std::stringstream stream;
    stream << "POST " << path;
    stream << " HTTP/1.0\r\n";
    stream << "Host: " << host << "\r\n";
    stream << "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3\r\n";
    stream << "Content-Type:application/x-www-form-urlencoded\r\n";
    stream << "Content-Length:" << post.length() << "\r\n";
    stream << "Connection:close\r\n\r\n";
    stream << post.c_str();
    return SocketHttp(host, stream.str(), nPort);
}
std::string CHttpConnect::HttpGet(std::string host)
{
    //GET����ʽ
    std::stringstream stream;
    string path;
    short nPort = ParseUrl(host, path);
    stream << "GET " << path;
    stream << " HTTP/1.0\r\n";
    stream << "Host: " << host << "\r\n";
    stream << "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3\r\n";
    stream << "Connection:close\r\n\r\n";
    return SocketHttp(host, stream.str(), nPort);
}
void CHttpConnect::HttpDownload(std::string host, pfn_write_data pwrite_data, void* pattach)
{
    //GET����ʽ
    std::stringstream stream;
    string path;
    short nPort = ParseUrl(host, path);
    stream << "GET " << path;
    stream << " HTTP/1.0\r\n";
    stream << "Host: " << host << "\r\n";
    stream << "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3\r\n";
    stream << "Connection:close\r\n\r\n";
    SocketHttp(host, stream.str(), nPort, pwrite_data, pattach);
}

char * CHttpConnect::ReadFile(char *pathpic, int &pic_len) {
    //��ͼƬ��ȡ����
    FILE *fp = fopen(pathpic, "rb");     //���ļ�
    if (!fp) {
        MessageBoxA(NULL, "û���ҵ��ļ�λ��", 0, 0);
        return NULL;
    }
    fseek(fp, 0, SEEK_END);  //һֱѰ�ҵ��ļ�β��
    pic_len = ftell(fp);  //�õ�ͼƬ�ĳ���
    rewind(fp);  //rewind���ļ�ָ��ָ��ͷ
    char *pic_buf = new char[pic_len + 1];  //����һ���ռ��ڶ���
    memset(pic_buf, 0, pic_len + 1);  //����ļ�ָ��
    //��ȡ�ļ�����
    fread(pic_buf, sizeof(char), pic_len, fp);
    //���Խ��ļ��ٱ�����D:��
    /*
    MessageBoxA(NULL, "�ļ���ʼ", 0, 0);
    FILE *fpw = fopen("C:\\AA.jpg","wb");
    fwrite(pic_buf,sizeof(char), pic_len, fpw);
    fclose(fpw); //�ر��ļ���
    MessageBoxA(NULL, "�ļ�����", 0, 0);
    */
    fclose(fp);

    return pic_buf;
}
void file_con(char **buffer, LPCSTR file)
{
    FILE *fp = fopen(file, "rb+");
    fseek(fp, 0, SEEK_END);
    long l_file_len = ftell(fp);
    rewind(fp);

    *buffer = new char[l_file_len + 1];
    memset(*buffer, 0, l_file_len + 1);
    fread(*buffer, l_file_len, 1, fp);
    fclose(fp);
}
std::string upload(LPCSTR lpszServer, LPCSTR lpszAddr, LPCSTR file)
{
    WSADATA WSAData;
    if(WSAStartup(MAKEWORD(2,2),&WSAData)!= 0){
        return "0";
    }
    char *f = NULL;
    file_con(&f, file);
    SOCKET sock = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == INVALID_SOCKET)
        return "0";
    SOCKADDR_IN server;
    server.sin_family = AF_INET;
    server.sin_port = htons(80);
    struct hostent *host_addr = gethostbyname(lpszServer);
    if (host_addr == NULL)
        return "host_addr == NULL";
    server.sin_addr.s_addr = *((int *)*host_addr->h_addr_list);
    //if (::connect(sock, (SOCKADDR *)&server, sizeof(SOCKADDR_IN)) == SOCKET_ERROR)
    //{
    //    ::closesocket(sock);
    //    return "0";
    //}
    bool flag = true;
    setsockopt(sock, IPPROTO_IP, 2, (char*)&flag, sizeof(flag)); 
    printf("ip address = %s, port = %d\n", inet_ntoa(server.sin_addr), ntohs(server.sin_port));

    std::string header("");

    header += "POST ";
    header += lpszAddr;
    header += " HTTP/1.1\r\n";
    header += "User-Agent: Mozilla/4.0\r\n";
    header += "Host: ";
    header += lpszServer;
    header += "\r\n";
    header += "Pragma: no-cache\r\n";
    header += "Accept: */*\r\n";
    header += "Content-Type: multipart/form-data; boundary=----------------------------64b23e4066ed\r\n";
    std::string content("");
    content += "------------------------------64b23e4066ed\r\n";
    content += "Content-Disposition: form-data; name='id'\r\n\r\n";
    content += "3365863\r\n";
    content += "------------------------------64b23e4066ed\r\n";
    content += "Content-Disposition: form-data; name='myfiles'; filename='img.jpg'\r\n";
    content += "Content-Type: custom\r\n\r\n";
    content += f;
    content += "\r\n------------------------------64b23e4066ed--\r\n";

    char temp[64] = { 0 };
    sprintf(temp, "Content-Length: %d\r\n\r\n", content.length());
    header += temp;
    std::string str_http_request = header + content;
    send(sock, str_http_request.c_str(), str_http_request.length(), 0);
    char szBuffer[1024] = { 0 };
    while (true)
    {
        int nRet = ::recv(sock, szBuffer, sizeof(szBuffer), 0);
        if (nRet == 0 || nRet == WSAECONNRESET)
        {
            printf("Connection Closed.\n");
            break;
        }
        else if (nRet == SOCKET_ERROR)
        {
            printf("socket error\n");
            break;
        }
        else
        {
            printf("recv() returned %d bytes\n", nRet);
            printf("received: %s\n", szBuffer);
            break;
        }
    }
    ::closesocket(sock);
    //delete[] lrc;
    return szBuffer;
}
//void main() {
//    upload("localhost", "http://127.0.0.1:8111/blog/uploadfile", "e:\/a.jpg")
//}
int main(int argc, char* argv[])
{
    int a;
    char text[] = "C:\\Users\\hp\\Desktop\\cailiao\\4.jpg";
    char* path= text;
    char *file = CHttpConnect::ReadFile(path,a);
    char post[1024] = { 0 };
    //string result = CHttpConnect::HttpPost("127.0.0.1:8111/blog/uploadfile", post);
    upload("localhost", "http://127.0.0.1:8111/blog/uploadfile", "C:\\Users\\hp\\Desktop\\cailiao\\4.jpg");
    //std::cout << result << std::endl;
    return 0;
}