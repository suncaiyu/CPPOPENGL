#pragma once
#include <iostream>
using namespace std;

typedef size_t(*pfn_write_data)(char *buffer, size_t size, size_t nitems, void *pattach);
//�ŵ�:����Ҫ������������,ȱ��:���ܵ�һ��:��֧��301��ת
class CHttpConnect
{
public:
    CHttpConnect();
    ~CHttpConnect(void);
    static string HttpPost(std::string host, std::string post);
    static string HttpGet(std::string host);
    static char *ReadFile(char *pathpic, int &pic_len);
    static void HttpDownload(std::string host, pfn_write_data pwrite_data, void* pattach = NULL);
private:
    static short ParseUrl(std::string& host, std::string& path);
    static string SocketHttp(std::string host, std::string request, short port, pfn_write_data pwrite_data = NULL, void* pattach = NULL);
};